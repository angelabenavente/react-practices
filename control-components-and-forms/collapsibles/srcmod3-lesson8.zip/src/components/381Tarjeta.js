import React from 'react';


class Tarjeta381 extends React.Component {
  render() {
    const { name, description, idioma, age, image } = this.props;
    const genders = this.props.genders.join(', ');

    return (
      <div className="card__id">
        <h3 id="cardName">{name === '' ? "Nombre" : name}</h3>
        <p id="cardDescription">{description === '' ? "Descripción" : description}</p>
        <p id="cardIdioma">{idioma === '' ? "Idioma" : idioma}</p>
        <p id="cardAge">{age === '' ? "Edades" : age}</p>
        <p id="cardGender">{genders === '' ? "Género" : genders}</p>
        <img id="cardImage" src={image} alt="image"></img>
      </div>
    );
  }
}

export default Tarjeta381;