import React from 'react';
import Form from './Form';

const Header = props => {
  return <Form /*renderText*/propsDeForm={props.propsDeHeader}/>
}

export default Header;