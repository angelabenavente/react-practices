import React, { Component } from 'react';


class CityImage extends Component {
   
    render() {
      return (
        <div className={this.wrapperClass}>
            <textarea className="Text-area" name="" id="" cols="30" rows="10" ></textarea>
        </div>
      );
    }
  }
  
  export default CityImage;